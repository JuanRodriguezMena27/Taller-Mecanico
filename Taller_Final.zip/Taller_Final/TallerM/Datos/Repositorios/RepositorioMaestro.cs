﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Datos.Repositorios
{
    public class RepositorioMaestro:Repository
    {
        protected List<SqlParameter> parameters;

        protected int ExcuteNonQuery(string transactSql)
        {
            using (var conexion = ObtenerConexion())
            {
                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandText = transactSql;
                    comando.CommandType = CommandType.Text;
                    foreach (SqlParameter item in parameters)
                    {
                        comando.Parameters.Add(item);
                    }
                    int result = comando.ExecuteNonQuery();
                    parameters.Clear();
                    return result;
                }
            }
        }
        protected DataTable ExcuteReader(string transactSql)
        {
            using (var conexion = ObtenerConexion())
            {
                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandText = transactSql;
                    comando.CommandType = CommandType.Text;
                    SqlDataReader reader = comando.ExecuteReader();
                    using (var tabla = new DataTable())
                    {
                        tabla.Load(reader);
                        reader.Dispose();
                        return tabla;

                    }
                }
            }
        }
    }
}
