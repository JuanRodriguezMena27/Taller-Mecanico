﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Datos.Repositorios
{
    public class Repository
    {
        private readonly string ConnectionString;

        public Repository()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["Conexion"].ToString();
        }
        protected SqlConnection ObtenerConexion()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
