﻿using Datos.Contratos;
using Datos.Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Datos.Repositorios
{
    public class RepositorioReparacion : RepositorioMaestro, IRepositorioReparacion
    {
        private string selectAll;
        private string insert;
        private string update;
        private string delete;
        public RepositorioReparacion()
        {
            selectAll = "SELECT *FROM Automovil";
            insert = "INSERT INTO Automovil (Placa,Marca,Dueño,DañoPresentado,FechaReparacion,TipoCoche,CosteReparacion)VALUES " +
                "(@Placa,@Marca,@Dueño,@DañoPresentado,@FechaReparacion,@TipoCoche,@CosteReparacion)";
            update = "UPDATE Automovil SET Placa=@Placa,Marca=@Marca,Dueño=@Dueño,DañoPresentado=@DañoPresentado,FechaReparacion=@FechaReparacion,TipoCoche=@TipoCoche,CosteReparacion=@CosteReparacion WHERE Placa=@Placa";
            delete = "DELETE Automovil WHERE Placa=@Placa";
        }
        public int Add(Reparacion entity)
        {
            parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@Placa", entity.Placa));
            parameters.Add(new SqlParameter("@Marca", entity.Marca));
            parameters.Add(new SqlParameter("@Dueño", entity.NombreDueño));
            parameters.Add(new SqlParameter("@DañoPresentado", entity.TipoReparacion));
            parameters.Add(new SqlParameter("@FechaReparacion", entity.FechaReparacion));
            parameters.Add(new SqlParameter("@TipoCoche", entity.TipoCoche));
            parameters.Add(new SqlParameter("@CosteReparacion", entity.CostoReparacion));
            return ExcuteNonQuery(insert);
        }

        public int Edit(Reparacion entity)
        {
            parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@Placa", entity.Placa));
            parameters.Add(new SqlParameter("@Marca", entity.Marca));
            parameters.Add(new SqlParameter("@Dueño", entity.NombreDueño));
            parameters.Add(new SqlParameter("@DañoPresentado", entity.TipoReparacion));
            parameters.Add(new SqlParameter("@FechaReparacion", entity.FechaReparacion));
            parameters.Add(new SqlParameter("@TipoCoche", entity.TipoCoche));
            parameters.Add(new SqlParameter("@CosteReparacion", entity.CostoReparacion));
            return ExcuteNonQuery(update);
        }

        public IEnumerable<Reparacion> GetAll()
        {
            var TablaResultado = ExcuteReader(selectAll);
            var ListaAutomovil = new List<Reparacion>();
            foreach (DataRow item in TablaResultado.Rows)
            {
                ListaAutomovil.Add(new Reparacion
                {
                    Placa = item[0].ToString(),
                    Marca = item[1].ToString(),
                    NombreDueño = item[2].ToString(),
                    TipoReparacion = item[3].ToString(),
                    FechaReparacion = DateTime.Parse(item[4].ToString()),
                    TipoCoche = item[5].ToString(),
                    CostoReparacion = decimal.Parse(item[6].ToString())
                });
            }
            return ListaAutomovil;

        }

        public int Remove(string placa)
        {
            parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@Placa", placa));
            return ExcuteNonQuery(delete);
        }
    }
}
