﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos.Entidades
{
    public class Reparacion
    {
        public string Placa {  get; set; }
        public string Marca { get; set; }
        public DateTime FechaReparacion { get; set; }
        public string NombreDueño { get; set; }
        public string TipoReparacion { get; set; }
        public string TipoCoche { get; set; }
        public decimal CostoReparacion { get; set; }
               
    }
}
