﻿using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logica;

namespace WindowsFormsApp1
{
    public partial class FormReparacion : Form
    {
        double costoAutoReparacionL;
        double costoAutoReparacion;
        double costoAutoReparacionR;
        double costoAutoReparacionP;
        double costoAutoReparacionC;
        double costoAutoReparacionCL;
        double costoCamion = 100.000;
        double Llenarllantas = 5.0000;
        double Repararmotor = 700.0000;
        double Pintarauto = 800.0000;
        double Cambioaceite = 140.0000;
        double Cambiollantas = 10.0000;
        string costoReparacionTotal;
        ReparacionModels models = new ReparacionModels();
        public FormReparacion()
        {
            InitializeComponent();
            panel1.Enabled = false;
        }
        private void Restart()
        {
            txtCostoReparacion.Clear();
            txtDueño.Clear();
            txtMarca.Clear();
            txtPlaca.Clear();
        }
        private void MostraTabla()
        {
            try
            {
                dataTable.DataSource = models.GetAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void FormReparacion_Load(object sender, EventArgs e)
        {
            MostraTabla();
        }
        private void cbReparacionTipo_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            switch (cbReparacionTipo.SelectedItem.ToString())
            {
                case "Llenar llantas desinfladas ":
                    txtCostoReparacion.Clear();
                    txtCostoReparacion.Text = Convert.ToString(Llenarllantas);
                    break;
                case "Llenar llantas desinfladas para Camion":
                    costoAutoReparacionL = Llenarllantas + costoCamion;
                    txtCostoReparacion.Text = Convert.ToString(costoAutoReparacionL);
                    break;
                case "Reparar motor":
                    txtCostoReparacion.Clear();
                    txtCostoReparacion.Text = Convert.ToString(Repararmotor);
                    break;
                case "Reparan Motor de Camion":
                    costoAutoReparacionR = Repararmotor + costoCamion;
                    txtCostoReparacion.Text = Convert.ToString(costoAutoReparacionR);
                    break;
                case "Pintar auto":
                    costoAutoReparacion = Pintarauto;
                    txtCostoReparacion.Text = Convert.ToString(costoAutoReparacion);
                    break;
                case "Pintar Camion":
                    costoAutoReparacionP = Pintarauto + costoCamion;
                    txtCostoReparacion.Text = Convert.ToString(costoAutoReparacionP);
                    break;
                case "Cambio De Aceite":
                    costoAutoReparacion = Cambioaceite;
                    txtCostoReparacion.Text = Convert.ToString(costoAutoReparacion);
                    break;
                case "Cambio De Aceite para Camion":
                    costoAutoReparacionC = Cambioaceite + costoCamion;
                    txtCostoReparacion.Text = Convert.ToString(costoAutoReparacionC);
                    break;
                case "Cambio de Llantas":
                    costoAutoReparacion = Cambiollantas;
                    txtCostoReparacion.Text = Convert.ToString(costoAutoReparacion);
                    break;
                case "Cambio De Llantas para Camion":
                    costoAutoReparacionCL = Cambiollantas + costoCamion;
                    txtCostoReparacion.Text = Convert.ToString(costoAutoReparacionCL);
                    break;
                default:
                    break;
            }
        }

        private void cbTipoAutomovil_SelectedIndexChanged(object sender, EventArgs e)
        {
            costoAutoReparacionP = Pintarauto + costoCamion;
            costoAutoReparacionC = Cambioaceite + costoCamion;
            costoAutoReparacionCL = Cambiollantas + costoCamion;
            string costoReparacionTotal;
            switch (cbTipoAutomovil.SelectedItem.ToString())
            {
                case "Camion":
                    // Si se selecciona "Opción 1", habilitar comboBox2
                    cbReparacionTipo.Items.Clear();
                    cbReparacionTipo.Items.Add("Llenar llantas desinfladas para Camion");
                    cbReparacionTipo.Items.Add("Reparan Motor de Camion");
                    cbReparacionTipo.Items.Add("Pintar Camion");
                    cbReparacionTipo.Items.Add("Cambio De Aceite para Camion");
                    cbReparacionTipo.Items.Add("Cambio De Llantas para Camion");
                    break;
                case "Automovil Personal":
                    cbReparacionTipo.Items.Clear();
                    cbReparacionTipo.Items.Add("Llenar llantas desinfladas");
                    cbReparacionTipo.Items.Add("Reparar motor");
                    cbReparacionTipo.Items.Add("Pintar auto");
                    cbReparacionTipo.Items.Add("Cambio De Aceite");
                    cbReparacionTipo.Items.Add("Cambio De Llantas");

                    break;
                default:
                    // Si se selecciona cualquier otra opción, habilitar comboBox2

                    break;

            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            models.Placa = txtPlaca.Text;
            models.Marca = txtMarca.Text;
            models.TipoReparacion = cbReparacionTipo.Text;
            models.CostoReparacion = Convert.ToDecimal(txtCostoReparacion.Text);
            models.FechaReparacion = Convert.ToDateTime(dtFechaRegistroCoche.Value);
            models.NombreDueño = txtDueño.Text;
            models.TipoCoche = cbTipoAutomovil.Text;

            bool valid = new Ayuda.DataValidation(models).valitedate();

            if (valid == true)
            {
                string result = models.SaveChange();
                MessageBox.Show(result);
                MostraTabla();
                Restart();
            }
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            if(dataTable.SelectedRows.Count > 0)
            {
                models.estado = EstadoEntidad.edited;
                models.Placa = dataTable.CurrentRow.Cells[0].Value.ToString();
                txtPlaca.Text = dataTable.CurrentRow.Cells[0].Value.ToString();
                txtMarca.Text = dataTable.CurrentRow.Cells[1].Value.ToString();
                txtDueño.Text = dataTable.CurrentRow.Cells[3].Value.ToString();
                cbReparacionTipo.Text = dataTable.CurrentRow.Cells[4].Value.ToString();
                cbTipoAutomovil.Text = dataTable.CurrentRow.Cells[5].Value.ToString();
                txtCostoReparacion.Text = dataTable.CurrentRow.Cells[6].Value.ToString();
                txtPlaca.Enabled = false;
            }
            else
            {
                MessageBox.Show("Seleccione una columna");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dataTable.SelectedRows.Count > 0)
            {
                models.estado = EstadoEntidad.deleted;
                models.Placa = dataTable.CurrentRow.Cells[0].Value.ToString();
                string result = models.SaveChange();
                MessageBox.Show(result);
                MostraTabla();
                Restart();

            }
            else
            {
                MessageBox.Show("Seleccione una columna");
            }
        }

        private void dataTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnNuevaReparacion_Click(object sender, EventArgs e)
        {
            panel1.Enabled = true;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            panel1.Enabled = false;
        }
    }
}
