﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WindowsFormsApp1.Ayuda
{
    public class DataValidation
    {

        private ValidationContext Context;
        private List<ValidationResult> Results;
        private bool valid;
        private string message;

        public DataValidation(object instance)
        {
            Context = new ValidationContext(instance);
            Results = new List<ValidationResult>();
            valid = Validator.TryValidateObject(instance, Context, Results, true);
        }
        public bool valitedate()
        {
            if (valid == false)
            {
                foreach (ValidationResult item in Results)
                {
                    message += item.ErrorMessage + "\n";
                }
                System.Windows.Forms.MessageBox.Show(message);
            }
            return valid;
        }
    }
}
