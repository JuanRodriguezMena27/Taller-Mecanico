﻿using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Datos.Entidades;

namespace WindowsFormsApp1
{
    public partial class FrmCoche : Form
    {
        ReparacionModels models= new ReparacionModels();
        
        public FrmCoche()
        {
            InitializeComponent();
            panel1.Enabled = false;
        }

        private void Grilla2()
        {
            try
            {
                dataTable.DataSource = models.GetAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        
        private void cbTipoAutomovil_SelectedIndexChanged(object sender, EventArgs e)
        {

          
        }


        private void cbReparacionTipo_SelectedIndexChanged(object sender, EventArgs e)
        {

           
        }

        private void btnNuevoIngreso_Click(object sender, EventArgs e)
        {
            panel1.Enabled = true;
        }
       
        private void iconButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panelTitulo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelLateral_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtCostoReparacion_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtMarca_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDueño_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMatricula_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dtFechaRegistroCoche_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

        }

        private void FrmCoche_Load(object sender, EventArgs e)
        {
            Grilla2();
        }
    }
}
