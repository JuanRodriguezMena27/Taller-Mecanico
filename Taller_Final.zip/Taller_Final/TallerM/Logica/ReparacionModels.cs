﻿using Datos.Entidades;
using Datos.Repositorios;
using Datos.Contratos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Logica
{
    public class ReparacionModels
    {
        private string placa;
        private string marca;
        private DateTime fechaReparacion;
        private string nombreDueño;
        private string tipoReparacion;
        private string tipoCoche;
        private decimal costoReparacion;
        private List<Reparacion> ListaReparacion;
        
        private IRepositorioReparacion reparacion;
        RepositorioReparacion repositorio = new RepositorioReparacion();
        public EstadoEntidad estado {private get; set;}

        //[Required]
        public string Placa { get => placa; set => placa = value; }
        //[Required]
        //[RegularExpression("^[a-zA-Z ]+$", ErrorMessage = "ESTE PARAMETRO DEBE SER SOLO TEXTO, NO DEBE TENER CARACTERES ESPECIALES, NI NUMEROS")]
        public string Marca { get => marca; set => marca = value; }
        public DateTime FechaReparacion { get => fechaReparacion; set => fechaReparacion = value; }
        //[Required]
        //[RegularExpression("^[a-zA-Z ]+$", ErrorMessage = "ESTE PARAMETRO DEBE SER SOLO TEXTO, NO DEBE TENER CARACTERES ESPECIALES, NI NUMEROS")]
        public string NombreDueño { get => nombreDueño; set => nombreDueño = value; }
        //[Required]
        //[RegularExpression("^[a-zA-Z ]+$", ErrorMessage = "ESTE PARAMETRO DEBE SER SOLO TEXTO, NO DEBE TENER CARACTERES ESPECIALES, NI NUMEROS")]
        public string TipoReparacion { get => tipoReparacion; set => tipoReparacion = value; }
        public string TipoCoche { get => tipoCoche; set => tipoCoche = value; }
        public decimal CostoReparacion { get => costoReparacion; set => costoReparacion = value; }


        public ReparacionModels()
        {
            reparacion = new RepositorioReparacion();
        }
        public string SaveChange()
        {
            string mensaje = null;
            try
            {
                var reparacionDataModel = new Reparacion();
                reparacionDataModel.Placa = Placa;
                reparacionDataModel.Marca = Marca;
                reparacionDataModel.NombreDueño = NombreDueño;
                reparacionDataModel.FechaReparacion = FechaReparacion;
                reparacionDataModel.CostoReparacion = CostoReparacion;
                reparacionDataModel.TipoReparacion = TipoReparacion;
                reparacionDataModel.TipoCoche = TipoCoche;

                switch (estado)
                {
                    case EstadoEntidad.Added:
                        reparacion.Add(reparacionDataModel);
                        mensaje = "Agregado Correctamente";
                        break;
                    case EstadoEntidad.edited:
                        reparacion.Edit(reparacionDataModel);
                        mensaje = "Editado Correctamente";
                        break;
                    case EstadoEntidad.deleted:
                        reparacion.Remove(placa);
                        mensaje = "Eliminado Correctamente";
                        break;
                    default:
                        break;
                }


            }
            catch (Exception ex)
            {
                mensaje = ex.Message.ToString();
            }
            return mensaje;
        }
        public List<Reparacion> GetAll()
        {
            var ClientDataModel = reparacion.GetAll();
            ListaReparacion = new List<Reparacion>();
            foreach (Reparacion item in ClientDataModel)
            {
                ListaReparacion.Add(new Reparacion
                {
                    Placa = item.Placa,
                    Marca = item.Marca,
                    FechaReparacion = item.FechaReparacion,
                    NombreDueño = item.NombreDueño,
                    TipoReparacion = item.TipoReparacion,
                    TipoCoche = item.TipoCoche,
                    CostoReparacion = item.CostoReparacion
                });
            }
            return ListaReparacion;
        }

    }
}
